import json
import os
import re
import urllib.parse
import urllib.request
from pathlib import Path
from typing import List, Dict, Any, Generator, Tuple

import app.core.config as cfg
from app.core.llm import (
    get_primary_client,
    get_fallback_client,
    has_valid_primary_key,
    has_valid_fallback_key,
    get_openai_client,
    has_valid_gemini_key,
    has_valid_openai_endpoint,
)
from app.auditing.discrepancy_scanner import detect_heuristic_discrepancy


# ---------------------------------------------------------------------------
# 1. AUTO-LOAD .env SO GROQ / GEMINI KEYS ARE NEVER MISSED
# ---------------------------------------------------------------------------
def _ensure_env_loaded() -> None:
    """Loads .env from project root if environment variables are missing."""
    if os.environ.get("LLM_API_KEY"):
        return
    root_dir = Path(__file__).resolve().parent.parent.parent
    for env_name in (".env", ".env.example"):
        env_path = root_dir / env_name
        if env_path.exists():
            try:
                for line in env_path.read_text(encoding="utf-8", errors="ignore").splitlines():
                    line = line.strip()
                    if not line or line.startswith("#") or "=" not in line:
                        continue
                    k, v = line.split("=", 1)
                    k, v = k.strip(), v.strip().strip('"').strip("'")
                    if k and v and k not in os.environ:
                        os.environ[k] = v
                if getattr(cfg, "LLM_API_KEY", "") in ("", None) and os.environ.get("LLM_API_KEY"):
                    cfg.LLM_API_KEY = os.environ["LLM_API_KEY"]
                if getattr(cfg, "LLM_MODEL", "") in ("", None) and os.environ.get("LLM_MODEL"):
                    cfg.LLM_MODEL = os.environ["LLM_MODEL"]
                if getattr(cfg, "LLM_BASE_URL", "") in ("", None) and os.environ.get("LLM_BASE_URL"):
                    cfg.LLM_BASE_URL = os.environ["LLM_BASE_URL"]
            except Exception:
                pass


_ensure_env_loaded()


BASE_SYSTEM_PROMPT = """You are RagIT, a Visual-First Document Intelligence & Compliance Assistant.
Answer strictly and exclusively using the provided numbered source excerpts.

STRICT GROUNDING & ANTI-WALL-OF-TEXT RULES:
1. CITATIONS: Cite every fact or number using [1], [2], etc.
2. UNVERIFIED REFUSAL: If the excerpts do not contain the answer, reply ONLY with:
   "I cannot verify this information in the provided document excerpts."
3. ZERO LONG PARAGRAPHS (MANDATORY):
   - NEVER copy-paste raw paragraphs from the excerpts.
   - Start with a 1-sentence **Direct Answer Headline** with citations (e.g., `✅ **Direct Answer:** ... [1]`).
   - Use at most **3 short bullet points** (MAXIMUM 20 words per bullet).
   - Put ALL numbers, rates, years, percentages, or comparisons into a **Markdown Table** instead of text!
   - Include a `Visual Scale` column in every numeric table using 10-character block bars (`█` and `░`), which the UI renders as graphic bars:
     | Item / Metric | 2024 / Target | 2023 / Actual | Visual Scale | Citation |
     | :--- | :--- | :--- | :--- | :--- |
     | **US Dollar (USD)** | 1.04 (Avg: 1.08) | 1.11 (Avg: 1.08) | `██░░░░░░░░` | [1] |
     | **Chinese Renminbi (CNY)** | 7.60 (Avg: 7.79) | 7.86 (Avg: 7.66) | `█████████░` | [1] |
"""


# ---------------------------------------------------------------------------
# 2. VISUAL BAR, TABLE & CHART HELPERS
# ---------------------------------------------------------------------------
def _make_unicode_bar(value: float, max_val: float = 100.0, width: int = 10) -> str:
    """Creates a 10-block bar that the RagIT UI converts into a cyan graphic bar."""
    if max_val <= 0:
        max_val = 100.0
    ratio = max(0.1, min(1.0, abs(value) / max_val))
    filled = max(1, int(round(ratio * width)))
    return "`" + ("█" * filled) + ("░" * (width - filled)) + "`"


def _extract_numeric_value(cell_text: str) -> Tuple[float | None, bool]:
    """Extracts the first meaningful metric number from a table cell."""
    cleaned = re.sub(r"\[\d+\]", "", cell_text)
    cleaned = re.sub(r"[*_`~]", "", cleaned).strip()
    if not cleaned or "█" in cleaned:
        return None, False

    is_pct = "%" in cleaned
    match = re.search(r"(-?\d+(?:,\d{3})*(?:\.\d+)?)", cleaned)
    if not match:
        return None, False

    raw_num = match.group(1).replace(",", "")
    try:
        val = float(raw_num)
        if not is_pct and "$" not in cleaned and 1990 <= val <= 2035 and "." not in raw_num:
            return None, False
        return val, is_pct
    except ValueError:
        return None, False


def _build_auto_chart_markdown(
    query: str,
    response_text: str,
    chunks: List[Dict[str, Any]]
) -> str:
    """
    Builds a Dark-Mode Chart.js Bar Graph image URL from any Markdown table
    in the response so the user gets an actual visual chart underneath the table.
    """
    if not response_text or "I cannot verify this information" in response_text:
        return ""
    if "quickchart.io/chart" in response_text:
        return ""

    labels: List[str] = []
    series_a: List[float] = []
    series_b: List[float] = []
    header_a = "Metric A"
    header_b = "Metric B"
    has_two_series = False

    lines = [line.strip() for line in response_text.splitlines() if "|" in line]
    table_lines = [line for line in lines if line.startswith("|") and line.endswith("|")]

    if len(table_lines) >= 3:
        headers = [re.sub(r"[*_`]", "", h).strip() for h in table_lines[0].strip("|").split("|")]
        if len(headers) >= 2:
            header_a = headers[1][:22] or "Value 1"
        if len(headers) >= 3:
            header_b = headers[2][:22] or "Value 2"

        for row in table_lines[2:]:
            if re.match(r"^\|[\s:\-|]+\|$", row):
                continue
            cols = [c.strip() for c in row.strip("|").split("|")]
            if len(cols) < 2:
                continue

            row_label = re.sub(r"\[\d+\]|[*_`~]", "", cols[0]).strip()[:22]
            if not row_label or row_label.lower() in ("source record", "metric", "item", "---"):
                continue

            val1, _ = _extract_numeric_value(cols[1])
            val2, _ = _extract_numeric_value(cols[2]) if len(cols) >= 3 else (None, False)

            if val1 is not None and val2 is not None:
                labels.append(row_label)
                series_a.append(val1)
                series_b.append(val2)
                has_two_series = True
            elif val1 is not None:
                labels.append(row_label)
                series_a.append(val1)

    if not labels or (len(labels) < 2 and not has_two_series):
        return ""

    datasets = [
        {
            "label": header_a,
            "data": series_a[:6],
            "backgroundColor": "rgba(6, 182, 212, 0.85)",
            "borderColor": "#06b6d4",
            "borderWidth": 1,
            "borderRadius": 6,
        }
    ]
    if has_two_series and len(series_b) == len(series_a):
        datasets.append(
            {
                "label": header_b,
                "data": series_b[:6],
                "backgroundColor": "rgba(16, 185, 129, 0.85)",
                "borderColor": "#10b981",
                "borderWidth": 1,
                "borderRadius": 6,
            }
        )

    chart_config = {
        "type": "bar",
        "data": {"labels": labels[:6], "datasets": datasets},
        "options": {
            "plugins": {
                "legend": {"display": True, "labels": {"color": "#e2e8f0"}},
                "title": {
                    "display": True,
                    "text": "Verified Metric Comparison",
                    "color": "#f8fafc",
                    "font": {"size": 14, "weight": "bold"},
                },
            },
            "scales": {
                "y": {
                    "beginAtZero": True,
                    "ticks": {"color": "#94a3b8"},
                    "grid": {"color": "rgba(148, 163, 184, 0.15)"},
                },
                "x": {
                    "ticks": {"color": "#e2e8f0"},
                    "grid": {"display": False},
                },
            },
        },
    }

    try:
        encoded = urllib.parse.quote(json.dumps(chart_config, separators=(",", ":")))
        chart_url = f"https://quickchart.io/chart?w=520&h=240&devicePixelRatio=2&bkg=%230f172a&c={encoded}"
        return f"\n\n📊 **Visual Metric Graph**\n![Verified Metric Graph]({chart_url})"
    except Exception:
        return ""


def _enforce_concise_output(text: str) -> str:
    """
    Post-processes LLM output to trim any runaway wall-of-text bullets
    while preserving Markdown tables, charts, and citations.
    """
    if not text or "I cannot verify this information" in text:
        return text

    out_lines = []
    for line in text.splitlines():
        stripped = line.strip()
        # Keep tables, headers, images, and short lines untouched
        if (
            not stripped
            or stripped.startswith("|")
            or stripped.startswith("#")
            or stripped.startswith("!")
            or stripped.startswith("---")
            or len(stripped) <= 240
        ):
            out_lines.append(line)
            continue

        # If a bullet or paragraph exceeds 240 chars, keep only its first 2 sentences + citations
        citations = " ".join(re.findall(r"\[\d+\]", stripped))
        sentences = re.split(r"(?<=[.!?])\s+", stripped)
        short_text = " ".join(sentences[:2])
        if len(short_text) > 240:
            short_text = short_text[:220].rsplit(" ", 1)[0] + "..."
        if citations and citations not in short_text:
            short_text += f" {citations}"
        out_lines.append(short_text)

    return "\n".join(out_lines)


# ---------------------------------------------------------------------------
# 3. SMART QUERY-FOCUSED EXTRACTIVE FALLBACK (NO RAW CHUNK DUMPING)
# ---------------------------------------------------------------------------
def _extract_best_sentences(query: str, text: str, max_sentences: int = 2) -> str:
    """Picks only the 1-2 sentences from a chunk that best match the query and contain numbers."""
    clean_text = re.sub(r"\s+", " ", text).strip()
    sentences = re.split(r"(?<=[.!?])\s+", clean_text)
    if not sentences:
        return clean_text[:180]

    q_words = {
        w.lower()
        for w in re.findall(r"[a-zA-Z0-9]{3,}", query)
        if w.lower() not in {"what", "the", "and", "for", "with", "from", "that", "this", "are", "was", "were"}
    }

    scored = []
    for idx, s in enumerate(sentences):
        s_lower = s.lower()
        overlap = sum(2 for w in q_words if w in s_lower)
        num_bonus = 2 if re.search(r"\d+\.\d+|\d+%", s) else 0
        # Penalize overly long run-on sentences
        length_penalty = 1 if len(s) > 260 else 0
        scored.append((overlap + num_bonus - length_penalty, -idx, s))

    scored.sort(reverse=True)
    chosen = [item[2] for item in scored[:max_sentences]]

    result = " ".join(chosen).strip()
    if len(result) > 220:
        # Slice around the part where numbers or query matches appear
        result = result[:215].rsplit(" ", 1)[0] + "..."
    return result


def _extract_metrics_table_from_chunks(query: str, chunks: List[Dict[str, Any]]) -> str:
    """
    Scans chunks for multi-number rows (e.g. Currency Exchange Rates, Financial Figures, SLAs)
    and formats them into a clean Markdown Table with cyan visual bars.
    """
    rows = []
    max_num = 1.0

    for c in chunks[:2]:
        cid = c.get("citation_id", 1)
        text = re.sub(r"\s+", " ", c.get("parent_text", "")).strip()

        # Pattern A: Label followed by 2 to 4 decimal numbers (like USD 1.04 1.11 1.08 1.08)
        pattern_multi = re.findall(
            r"([A-Z][a-zA-Z\s\-]{2,25}?)\s+(?:[A-Z]{3}\s+)?(\d+\.\d+)\s+(\d+\.\d+)(?:\s+(\d+\.\d+))?(?:\s+(\d+\.\d+))?",
            text
        )
        for match in pattern_multi[:5]:
            label = match[0].strip()
            n1, n2, n3, n4 = match[1], match[2], match[3] or "—", match[4] or "—"
            try:
                v = float(n1)
                max_num = max(max_num, v, float(n2))
                rows.append((label, n1, n2, n3, n4, v, cid))
            except ValueError:
                pass

    if rows:
        table = [
            "| Metric / Item | Value 1 (Latest) | Value 2 (Prior) | Avg / Target 1 | Avg / Target 2 | Visual Scale | Cite |",
            "| :--- | :--- | :--- | :--- | :--- | :--- | :--- |",
        ]
        for label, n1, n2, n3, n4, v, cid in rows:
            bar = _make_unicode_bar(v, max_num)
            table.append(f"| **{label}** | {n1} | {n2} | {n3} | {n4} | {bar} | [{cid}] |")
        return "\n".join(table)

    # Pattern B: Sentences containing percentages or EUR/USD million figures
    metric_rows = []
    for c in chunks[:2]:
        cid = c.get("citation_id", 1)
        text = re.sub(r"\s+", " ", c.get("parent_text", "")).strip()
        for m in re.finditer(r"([A-Za-z][A-Za-z\s\-]{3,28}?)\s+(?:of|was|were|is|at|around|approx\.)?\s*(?:€|\$|EUR|USD)?\s*(-?\d+(?:\.\d+)?\s*(?:%|million|billion)?)", text):
            lbl = m.group(1).strip()
            val_str = m.group(2).strip()
            if any(char.isdigit() for char in val_str) and len(lbl) >= 4:
                num_m = re.search(r"-?\d+(?:\.\d+)?", val_str)
                if num_m:
                    val_f = float(num_m.group(0))
                    if not (1990 <= val_f <= 2035 and "." not in val_str):
                        max_num = max(max_num, abs(val_f))
                        metric_rows.append((lbl[:24], val_str, abs(val_f), cid))
            if len(metric_rows) >= 4:
                break

    if metric_rows:
        table = [
            "| Extracted Metric | Verified Value | Visual Scale | Citation |",
            "| :--- | :--- | :--- | :--- |",
        ]
        for lbl, val_str, val_f, cid in metric_rows[:4]:
            bar = _make_unicode_bar(val_f, max_num)
            table.append(f"| **{lbl}** | {val_str} | {bar} | [{cid}] |")
        return "\n".join(table)

    return ""


def _build_extractive_fallback(query: str, chunks: List[Dict[str, Any]]) -> str:
    """
    Concise, Visual-First Extractive Synthesis when offline or in test mode.
    Never dumps full raw paragraphs; extracts only matching key sentences + a visual table.
    """
    if not chunks:
        return "I cannot verify this information in the provided document excerpts."

    top_c = chunks[0]
    cid = top_c.get("citation_id", 1)
    doc = top_c.get("filename", "Document")
    page = top_c.get("page", 1)
    excerpt = top_c.get("parent_text", "").strip()

    concise_primary = _extract_best_sentences(query, excerpt, max_sentences=2)
    parts = [
        f"✅ **Executive Summary [{cid}]:** {concise_primary}",
    ]

    metrics_table = _extract_metrics_table_from_chunks(query, chunks)
    if metrics_table:
        parts.append(f"\n\n### 📋 Verified Data Table\n{metrics_table}")

    if len(chunks) > 1 and chunks[1].get("dense_score", 0.0) >= 0.45:
        second_c = chunks[1]
        cid2 = second_c.get("citation_id", 2)
        excerpt2 = second_c.get("parent_text", "").strip()
        if excerpt2 and excerpt2 != excerpt:
            concise_secondary = _extract_best_sentences(query, excerpt2, max_sentences=1)
            parts.append(f"\n\n- **Supporting Evidence [{cid2}]:** {concise_secondary}")
            disc = (
                detect_heuristic_discrepancy(excerpt, excerpt2)
                or detect_heuristic_discrepancy(excerpt2, excerpt)
            )
            if disc and disc.get("status") == "CONTRADICTION":
                delta_msg = disc.get("discrepancy_delta", "Mismatch detected")
                parts.append(
                    f"\n\n⚠️ **Cross-Modal Audit Alert:** {delta_msg} [{cid}][{cid2}]"
                )

    parts.append(f"\n\n*(Source: `{doc}`, Page {page})*")
    full_fallback = "".join(parts)
    chart_md = _build_auto_chart_markdown(query, full_fallback, chunks)
    return full_fallback + chart_md


# ---------------------------------------------------------------------------
# 4. DIRECT HTTPS CALL HELPER (IF SDK CLIENT IS UNCONFIGURED)
# ---------------------------------------------------------------------------
def _direct_http_chat_completion(
    system_prompt: str,
    user_prompt: str,
) -> Tuple[str | None, Dict[str, Any]]:
    """
    Calls Groq REST API directly using standard library urllib if get_primary_client()
    was skipped due to config initialization order.
    Skipped automatically during offline pytest runs.
    """
    if "PYTEST_CURRENT_TEST" in os.environ:
        return None, {}

    _ensure_env_loaded()
    api_key = os.environ.get("LLM_API_KEY") or getattr(cfg, "LLM_API_KEY", "")
    if not api_key or api_key.startswith("your_"):
        return None, {}

    base_url = (
        os.environ.get("LLM_BASE_URL")
        or getattr(cfg, "LLM_BASE_URL", "")
        or "https://api.groq.com/openai/v1"
    ).rstrip("/")
    model = (
        os.environ.get("LLM_MODEL")
        or getattr(cfg, "LLM_MODEL", "")
        or "llama-3.1-8b-instant"
    )

    payload = json.dumps({
        "model": model,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        "temperature": 0.15,
        "max_tokens": 750,
    }).encode("utf-8")

    req = urllib.request.Request(
        f"{base_url}/chat/completions",
        data=payload,
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}",
            "User-Agent": "RagIT-AuditGuard/1.0",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=12) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            text = data["choices"][0]["message"]["content"]
            usage = data.get("usage", {})
            return text, {
                "prompt_tokens": int(usage.get("prompt_tokens", 0)),
                "completion_tokens": int(usage.get("completion_tokens", 0)),
                "total_tokens": int(usage.get("total_tokens", 0)),
                "generation_mode": "groq_primary",
                "model_used": model,
            }
    except Exception as e:
        print(f"Direct Groq REST call warning: {e}")
        return None, {}


# ---------------------------------------------------------------------------
# 5. MAIN GENERATION & STREAMING FUNCTIONS
# ---------------------------------------------------------------------------
def build_grounded_prompt(query: str, chunks: List[Dict[str, Any]], persona_addon: str = "") -> str:
    """Builds the context payload with numbered excerpts and linked visual table data."""
    context_lines = []
    for c in chunks:
        cid = c.get("citation_id", 1)
        page = c.get("page", 1)
        doc = c.get("filename", "Document")
        parent = c.get("parent_text", "").strip()
        block = f"[{cid}] (File: {doc}, Page {page}):\n{parent}"
        if c.get("linked_visuals"):
            vis_titles = ", ".join(v.get("title", "Visual") for v in c["linked_visuals"])
            block += f"\n(Linked Visual Evidence: {vis_titles})"
        context_lines.append(block + "\n")

    joined_context = "\n".join(context_lines)

    return f"""=== VERIFIED SOURCE EXCERPTS ===
{joined_context}
================================

USER QUESTION:
{query}

MANDATORY OUTPUT TEMPLATE:
1. **1-Line Direct Answer** with [1] citation.
2. **Key Takeaways**: Maximum 3 short bullet points (under 20 words each). Do NOT copy long sentences from the excerpt.
3. **Markdown Data Table**: Put ALL numbers, rates, dates, or comparisons into a table with a `Visual Scale` column using `` `████████░░` `` bars and a `Citation` column."""


def generate_grounded_answer_with_telemetry(
    query: str,
    chunks: List[Dict[str, Any]],
    persona_addon: str = ""
) -> Tuple[str, Dict[str, Any]]:
    """
    Synchronous grounded generation returning (answer_text, telemetry_dict).
    """
    system_content = BASE_SYSTEM_PROMPT
    if persona_addon:
        system_content += f"\n\nSPECIALIZED AUDIT PERSONA:\n{persona_addon}"

    user_content = build_grounded_prompt(query, chunks, persona_addon)

    # 1. Try Primary Fast API (Groq via configured client)
    if has_valid_primary_key():
        client = get_primary_client()
        if client is not None:
            try:
                response = client.chat.completions.create(
                    model=cfg.LLM_MODEL,
                    messages=[
                        {"role": "system", "content": system_content},
                        {"role": "user", "content": user_content}
                    ],
                    temperature=0.15,
                    max_tokens=750
                )
                text = response.choices[0].message.content or "No response from Groq."
                text = _enforce_concise_output(text)
                text += _build_auto_chart_markdown(query, text, chunks)
                usage = getattr(response, "usage", None)
                prompt_tok = int(getattr(usage, "prompt_tokens", 0) or 0)
                comp_tok = int(getattr(usage, "completion_tokens", 0) or 0)
                total_tok = int(getattr(usage, "total_tokens", 0) or (prompt_tok + comp_tok))
                return text, {
                    "prompt_tokens": prompt_tok,
                    "completion_tokens": comp_tok,
                    "total_tokens": total_tok,
                    "generation_mode": "groq_primary",
                    "model_used": cfg.LLM_MODEL,
                }
            except Exception as e:
                print(f"Primary Fast API (Groq) warning, attempting fallback: {e}")

    # 1b. Direct HTTPS Groq fallback if config/client did not initialize .env
    direct_text, direct_meta = _direct_http_chat_completion(system_content, user_content)
    if direct_text:
        direct_text = _enforce_concise_output(direct_text)
        direct_text += _build_auto_chart_markdown(query, direct_text, chunks)
        return direct_text, direct_meta

    # 2. Try Fallback (Google Gemini OpenAI-compatible endpoint)
    if has_valid_fallback_key():
        client = get_fallback_client()
        if client is not None:
            try:
                response = client.chat.completions.create(
                    model=cfg.FALLBACK_MODEL,
                    messages=[
                        {"role": "system", "content": system_content},
                        {"role": "user", "content": user_content}
                    ],
                    temperature=0.15,
                    max_tokens=750
                )
                text = response.choices[0].message.content or "No response from Gemini fallback."
                text = _enforce_concise_output(text)
                text += _build_auto_chart_markdown(query, text, chunks)
                usage = getattr(response, "usage", None)
                prompt_tok = int(getattr(usage, "prompt_tokens", 0) or 0)
                comp_tok = int(getattr(usage, "completion_tokens", 0) or 0)
                total_tok = int(getattr(usage, "total_tokens", 0) or (prompt_tok + comp_tok))
                return text, {
                    "prompt_tokens": prompt_tok,
                    "completion_tokens": comp_tok,
                    "total_tokens": total_tok,
                    "generation_mode": "gemini_fallback",
                    "model_used": cfg.FALLBACK_MODEL,
                }
            except Exception as e:
                print(f"Fallback API (Gemini) warning, attempting extractive fallback: {e}")

    # 3. Concise Visual Extractive AST Fallback (Offline Mode)
    fallback_text = _build_extractive_fallback(query, chunks)
    return fallback_text, {
        "prompt_tokens": 0,
        "completion_tokens": 0,
        "total_tokens": 0,
        "generation_mode": "extractive_fallback",
        "model_used": "extractive-ast-engine",
    }


def generate_grounded_answer(
    query: str,
    chunks: List[Dict[str, Any]],
    persona_addon: str = ""
) -> str:
    """Synchronous grounded generation returning the answer string."""
    answer, _ = generate_grounded_answer_with_telemetry(query, chunks, persona_addon)
    return answer


def stream_grounded_answer(
    query: str,
    chunks: List[Dict[str, Any]],
    persona_addon: str = ""
) -> Generator[str, None, None]:
    """
    Streams tokens in real-time from Primary Fast API (Groq) or Fallback (Gemini),
    and appends the visual chart once streaming completes.
    """
    system_content = BASE_SYSTEM_PROMPT
    if persona_addon:
        system_content += f"\n\nSPECIALIZED AUDIT PERSONA:\n{persona_addon}"

    user_content = build_grounded_prompt(query, chunks, persona_addon)

    # 1. Try Primary Fast API (Groq) Streaming
    if has_valid_primary_key():
        client = get_primary_client()
        if client is not None:
            try:
                stream = client.chat.completions.create(
                    model=cfg.LLM_MODEL,
                    messages=[
                        {"role": "system", "content": system_content},
                        {"role": "user", "content": user_content}
                    ],
                    temperature=0.15,
                    max_tokens=750,
                    stream=True
                )
                collected: List[str] = []
                for chunk in stream:
                    delta = chunk.choices[0].delta.content or ""
                    if delta:
                        collected.append(delta)
                        yield delta
                if collected:
                    full_text = "".join(collected)
                    chart_md = _build_auto_chart_markdown(query, full_text, chunks)
                    if chart_md:
                        yield chart_md
                    return
            except Exception as e:
                print(f"Primary Fast API (Groq) stream warning: {e}")

    # 1b. Direct HTTPS Groq call if client was not initialized
    direct_text, _ = _direct_http_chat_completion(system_content, user_content)
    if direct_text:
        direct_text = _enforce_concise_output(direct_text)
        direct_text += _build_auto_chart_markdown(query, direct_text, chunks)
        yield direct_text
        return

    # 2. Try Fallback (Gemini OpenAI-compatible) Streaming
    if has_valid_fallback_key():
        client = get_fallback_client()
        if client is not None:
            try:
                stream = client.chat.completions.create(
                    model=cfg.FALLBACK_MODEL,
                    messages=[
                        {"role": "system", "content": system_content},
                        {"role": "user", "content": user_content}
                    ],
                    temperature=0.15,
                    max_tokens=750,
                    stream=True
                )
                collected = []
                for chunk in stream:
                    delta = chunk.choices[0].delta.content or ""
                    if delta:
                        collected.append(delta)
                        yield delta
                if collected:
                    full_text = "".join(collected)
                    chart_md = _build_auto_chart_markdown(query, full_text, chunks)
                    if chart_md:
                        yield chart_md
                    return
            except Exception as e:
                print(f"Fallback API (Gemini) stream warning: {e}")

    # 3. Concise Offline Fallbacksss
    yield _build_extractive_fallback(query, chunks)