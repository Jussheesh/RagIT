/**
 * RagIT Visual Renderer (Chart.js + Mermaid.js + Status Pills)
 * Works automatically with both app/static/index.html and app/static/assistant/index.html
 */
(function () {
  // Initialize Mermaid once loaded
  function initMermaid() {
    if (window.mermaid) {
      const isDark =
        document.documentElement.classList.contains("dark") ||
        document.body.classList.contains("dark") ||
        window.matchMedia("(prefers-color-scheme: dark)").matches;

      window.mermaid.initialize({
        startOnLoad: false,
        theme: isDark ? "dark" : "default",
        securityLevel: "loose",
        fontFamily: "Inter, system-ui, sans-serif",
      });
    }
  }

  // Safely clean minor LLM JSON syntax quirks
  function parseChartJson(raw) {
    let cleaned = raw
      .trim()
      .replace(/^```(?:chartjs|chart|json)?/i, "")
      .replace(/```$/, "")
      .trim();
    // Remove trailing commas before } or ]
    cleaned = cleaned.replace(/,\s*([}\]])/g, "$1");
    return JSON.parse(cleaned);
  }

  // Render ```chartjs code blocks into interactive Chart.js canvases
  function renderCharts(root = document) {
    if (!window.Chart) return;
    const blocks = root.querySelectorAll(
      'pre code.language-chartjs, pre code.language-chart, pre code[class*="chartjs"]'
    );

    blocks.forEach((codeEl) => {
      const pre = codeEl.parentElement;
      if (!pre || pre.dataset.visualRendered === "true") return;

      const rawText = codeEl.textContent || "";
      // Wait if the JSON block is still streaming and incomplete
      if (!rawText.trim().endsWith("}")) return;

      try {
        const config = parseChartJson(rawText);
        pre.dataset.visualRendered = "true";

        const wrapper = document.createElement("div");
        wrapper.className = "ragit-visual-card ragit-chart-card";

        const canvas = document.createElement("canvas");
        wrapper.appendChild(canvas);

        pre.replaceWith(wrapper);
        new window.Chart(canvas.getContext("2d"), config);
      } catch (err) {
        // Ignore while streaming; if final and invalid, leave as clean code block
        console.warn("Chart.js parse skipped/pending:", err.message);
      }
    });
  }

  // Render ```mermaid code blocks into SVG diagrams
  async function renderMermaidDiagrams(root = document) {
    if (!window.mermaid) return;
    const blocks = root.querySelectorAll(
      'pre code.language-mermaid, pre code[class*="mermaid"]'
    );

    for (const codeEl of blocks) {
      const pre = codeEl.parentElement;
      if (!pre || pre.dataset.visualRendered === "true") return;

      const graphDef = (codeEl.textContent || "").trim();
      if (!graphDef || graphDef.length < 10) continue;

      try {
        pre.dataset.visualRendered = "true";
        const id = "ragit-mermaid-" + Math.random().toString(36).substring(2, 9);
        const { svg } = await window.mermaid.render(id, graphDef);

        const wrapper = document.createElement("div");
        wrapper.className = "ragit-visual-card ragit-mermaid-card";
        wrapper.innerHTML = svg;
        pre.replaceWith(wrapper);
      } catch (err) {
        // Reset flag in case it was mid-stream so it can retry when finished
        pre.dataset.visualRendered = "false";
      }
    }
  }

  // Convert [COMPLIANT], [DISCREPANCY DETECTED], [CRITICAL], [WARNING], [INFO] into UI badges
  function styleStatusBadges(root = document) {
    const badgeMap = {
      "[COMPLIANT]": '<span class="ragit-badge ragit-badge-success">✓ COMPLIANT</span>',
      "[PASS]": '<span class="ragit-badge ragit-badge-success">✓ PASS</span>',
      "[DISCREPANCY DETECTED]": '<span class="ragit-badge ragit-badge-danger">⚠ DISCREPANCY DETECTED</span>',
      "[CRITICAL]": '<span class="ragit-badge ragit-badge-danger">✖ CRITICAL</span>',
      "[FAIL]": '<span class="ragit-badge ragit-badge-danger">✖ FAIL</span>',
      "[WARNING]": '<span class="ragit-badge ragit-badge-warning">▲ WARNING</span>',
      "[INFO]": '<span class="ragit-badge ragit-badge-info">ℹ SUMMARY</span>',
    };

    const paragraphs = root.querySelectorAll("p, li, strong");
    paragraphs.forEach((el) => {
      if (el.dataset.badgeProcessed === "true" || el.children.length > 2) return;
      let html = el.innerHTML;
      let changed = false;
      for (const [pattern, replacement] of Object.entries(badgeMap)) {
        const regex = new RegExp(pattern, "g");
        if (regex.test(html)) {
          html = html.replace(regex, replacement);
          changed = true;
        }
      }
      if (changed) {
        el.innerHTML = html;
        el.dataset.badgeProcessed = "true";
      }
    });
  }

  // Master render function exposed globally
  window.renderBotVisuals = function (root = document) {
    renderCharts(root);
    renderMermaidDiagrams(root);
    styleStatusBadges(root);
  };

  // Inject clean card & badge styles automatically
  function injectStyles() {
    if (document.getElementById("ragit-visual-styles")) return;
    const style = document.createElement("style");
    style.id = "ragit-visual-styles";
    style.textContent = `
      .ragit-visual-card {
        margin: 14px 0;
        padding: 16px;
        border-radius: 12px;
        background: rgba(148, 163, 184, 0.08);
        border: 1px solid rgba(148, 163, 184, 0.22);
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
        overflow-x: auto;
      }
      .ragit-chart-card {
        max-width: 560px;
        max-height: 340px;
        display: flex;
        align-items: center;
        justify-content: center;
      }
      .ragit-mermaid-card {
        display: flex;
        justify-content: center;
        padding: 18px;
      }
      .ragit-badge {
        display: inline-flex;
        align-items: center;
        padding: 3px 10px;
        border-radius: 9999px;
        font-size: 0.75rem;
        font-weight: 700;
        letter-spacing: 0.03em;
        margin-right: 6px;
        vertical-align: middle;
      }
      .ragit-badge-success { background: rgba(16, 185, 129, 0.18); color: #10b981; border: 1px solid rgba(16, 185, 129, 0.35); }
      .ragit-badge-danger  { background: rgba(239, 68, 68, 0.18);  color: #ef4444; border: 1px solid rgba(239, 68, 68, 0.35); }
      .ragit-badge-warning { background: rgba(245, 158, 11, 0.18); color: #f59e0b; border: 1px solid rgba(245, 158, 11, 0.35); }
      .ragit-badge-info    { background: rgba(99, 102, 241, 0.18); color: #6366f1; border: 1px solid rgba(99, 102, 241, 0.35); }
    `;
    document.head.appendChild(style);
  }

  // Watch DOM changes so both index.html and assistant/index.html render visuals automatically
  let debounceTimer = null;
  function startObserver() {
    injectStyles();
    initMermaid();
    window.renderBotVisuals();

    const observer = new MutationObserver(() => {
      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(() => {
        window.renderBotVisuals();
      }, 180);
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true,
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", startObserver);
  } else {
    startObserver();
  }
})();